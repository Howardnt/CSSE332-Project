#include "kernel/types.h"
#include "user/user.h"

int main(int argc, char **argv)
{
  if (argc != 2) {
	printf("Usage: sleep <ticks>\n");
	exit(0);
  }

  int ticks = atoi(argv[1]);
  printf("%d\n", ticks);
  if (ticks < 0) {
	printf("Error: tick amount to sleep must be a possitive integer");
	exit(0);
  }
  
  sleep(ticks);

  exit(0);
}
